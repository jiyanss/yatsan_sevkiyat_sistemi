# Yatsan Sevkiyat Sistemi

Bu proje, Yatsan için geliştirilmiş bir sevkiyat yönetim sistemidir.

## Kurulum

1. Bağımlılıkları yükleyin:
\`\`\`bash
npm install
\`\`\`

2. Geliştirme sunucusunu başlatın:
\`\`\`bash
npm run dev
\`\`\`

3. Tarayıcınızda [http://localhost:3000](http://localhost:3000) adresini açın.

## Özellikler

- Kullanıcı girişi (Mağaza, Satış Destek, Sevkiyat Koordinasyon)
- Müşteri sipariş girişi
- Sipariş listesi görüntüleme
- Araç planlama takvimi (günlük/haftalık görünüm)
- Excel'e aktarma özelliği

## Teknolojiler

- Next.js 15
- React 19
- Tailwind CSS 4
- Radix UI
- Lucide Icons
