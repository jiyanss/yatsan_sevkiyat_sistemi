import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarDays } from "lucide-react";

export default function App() {
  const [page, setPage] = useState("login");
  // improvement: moved orders state to App
  // so both OrderEntryPage and PlanningPage can use same data
  const [orders, setOrders] = useState([]);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-blue-900 text-white py-4 px-8 flex justify-between items-center shadow-md">
        <h1 className="text-xl font-bold">Yatsan Sevkiyat Sistemi</h1>
        {page !== "login" && <Button onClick={() => setPage("login")}>Çıkış</Button>}
      </header>

      {page === "login" && <LoginPage onLogin={setPage} />}
      {/* improvement: pass orders and setOrders as props */}
      {page === "order" && <OrderEntryPage orders={orders} setOrders={setOrders} />}
      {/* improvement: orders data can also go to planning page */}
      {page === "planning" && <PlanningPage orders={orders} />}
    </div>
  );
}

function LoginPage({ onLogin }) {
  const [role, setRole] = useState("magaza");
  // fix: added state for input fields
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="flex justify-center items-center h-[80vh]">
      <Card className="w-[350px] shadow-lg">
        <CardHeader>
          <CardTitle className="text-center text-blue-900">Giriş Yap</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          {/* fix: inputs are now controlled components */}
          <Input 
            placeholder="Kullanıcı Adı" 
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
          <Input 
            placeholder="Şifre" 
            type="password" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <select
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="border rounded p-2 text-sm"
          >
            <option value="magaza">Mağaza</option>
            <option value="satis">Satış Destek</option>
            <option value="sevkiyat">Sevkiyat Koordinasyon</option>
          </select>
          <Button
            className="bg-blue-900"
            onClick={() => onLogin(role === "magaza" ? "order" : "planning")}
          >
            Giriş
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function OrderEntryPage({ orders, setOrders }) {
  // improvement: orders state comes from props now
  const [newOrder, setNewOrder] = useState({
    musteri: "",
    siparisNo: "",
    urun: "",
    miktar: "",
    teslimTarihi: "",
    aracTipi: "",
  });

  // improvement: keep fetch logic but in real app it will call API
  useEffect(() => {
    // if no data, use empty list first
    // if orders already filled in App, fetch won't run
    if (orders.length === 0) {
      fetch("/data/orders.json")
        .then((res) => res.json())
        .then((data) => setOrders(data))
        .catch(() => console.warn("Mock data not found, using empty list."));
    }
  }, []); // run only once on first render

  const handleChange = (e) => {
    setNewOrder({ ...newOrder, [e.target.name]: e.target.value });
  };

  const handleSave = () => {
    if (!newOrder.musteri || !newOrder.siparisNo) return;
    // improvement: use crypto.randomUUID() for unique ID
    setOrders([...orders, { id: crypto.randomUUID(), ...newOrder }]);
    setNewOrder({ musteri: "", siparisNo: "", urun: "", miktar: "", teslimTarihi: "", aracTipi: "" });
  };

  return (
    <div className="p-8 space-y-8">
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-blue-900">Müşteri Sipariş Girişi</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-4">
          <Input name="musteri" value={newOrder.musteri} onChange={handleChange} placeholder="Müşteri Adı" />
          <Input name="siparisNo" value={newOrder.siparisNo} onChange={handleChange} placeholder="Sipariş Numarası" />
          <Input name="urun" value={newOrder.urun} onChange={handleChange} placeholder="Ürün / Kategori" />
          <Input name="miktar" value={newOrder.miktar} onChange={handleChange} placeholder="Miktar (m³)" />
          <Input name="teslimTarihi" value={newOrder.teslimTarihi} onChange={handleChange} type="date" placeholder="Teslim Tarihi" />
          <select name="aracTipi" value={newOrder.aracTipi} onChange={handleChange} className="border rounded p-2 text-sm">
            <option value="">Araç Tipi Seçin</option>
            <option>Kamyonet</option>
            <option>Tır</option>
            <option>Panelvan</option>
          </select>
          <div className="col-span-3 flex justify-end">
            <Button className="bg-blue-900" onClick={handleSave}>Kaydet</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-md">
        <CardHeader>
          <CardTitle className="text-blue-900">Sipariş Listesi</CardTitle>
        </CardHeader>
        <CardContent>
          <table className="w-full text-sm border">
            <thead className="bg-gray-100">
              <tr>
                <th className="border p-2">Müşteri</th>
                <th className="border p-2">Sipariş No</th>
                <th className="border p-2">Ürün</th>
                <th className="border p-2">Miktar</th>
                <th className="border p-2">Araç Tipi</th>
                <th className="border p-2">Teslim Tarihi</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id}>
                  <td className="border p-2">{o.musteri}</td>
                  <td className="border p-2">{o.siparisNo}</td>
                  <td className="border p-2">{o.urun}</td>
                  <td className="border p-2">{o.miktar}</td>
                  <td className="border p-2">{o.aracTipi}</td>
                  <td className="border p-2">{o.teslimTarihi}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

function PlanningPage({ orders }) {
  const [view, setView] = useState("haftalik");
  const [plans, setPlans] = useState([]);

  // improvement: keep fetch logic
  useEffect(() => {
    fetch("/data/planning.json")
      .then((res) => res.json())
      .then((data) => setPlans(data))
      .catch(() => console.warn("Mock planning data not found."));
  }, []);

  // fix: added onClick for export to excel button
  const handleExportToExcel = () => {
    // in real app, here a library like 'xlsx' can be used to convert data to Excel
    alert("Excel export not ready yet. Can use a library like xlsx to do it.");
  };

  return (
    <div className="p-8">
      <Card className="shadow-md">
        <CardHeader className="flex justify-between items-center">
          <CardTitle className="text-blue-900 flex items-center gap-2">
            <CalendarDays className="w-5 h-5" /> Araç Planlama Takvimi
          </CardTitle>
          <div className="flex gap-2">
            <Button variant={view === "gunluk" ? "default" : "outline"} onClick={() => setView("gunluk")}>Günlük</Button>
            <Button variant={view === "haftalik" ? "default" : "outline"} onClick={() => setView("haftalik")}>Haftalık</Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="Pzt" className="w-full">
            <TabsList className="grid grid-cols-7">
              {['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'].map((d) => (
                <TabsTrigger key={d} value={d}>{d}</TabsTrigger>
              ))}
            </TabsList>
            {plans.map((day) => (
              <TabsContent key={day.gun} value={day.gun}>
                <div className="grid grid-cols-3 gap-4 mt-4">
                  {day.araclar.map((a) => (
                    <Card key={a.id} className="border-blue-200">
                      <CardHeader>
                        <CardTitle className="text-sm text-blue-800">{a.tip} #{a.id}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-xs text-gray-600">Doluluk: %{a.doluluk}</p>
                        <p className="text-xs text-gray-600">Sipariş Sayısı: {a.siparisSayisi}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
          <div className="flex justify-end mt-6">
            {/* fix: added onClick to the button */}
            <Button className="bg-green-600" onClick={handleExportToExcel}>Excel’e Aktar</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
