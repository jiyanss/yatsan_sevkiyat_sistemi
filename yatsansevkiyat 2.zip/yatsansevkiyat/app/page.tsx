"use client"

import { Card } from "../yatsan-sevkiyat/src/components/ui/card"

export default function SyntheticV0PageForDeployment() {
  return <Card />
}